import React, { useState, useEffect } from "react";
import {
  Heart,
  ShoppingBag,
  Search,
  Home,
  Grid3x3,
  User,
  ChevronLeft,
  CreditCard,
  Smartphone,
  Banknote,
  Check,
  Mail,
  Phone,
  MapPin,
  LogOut,
  Package,
  Camera,
  Pencil,
  Plus,
  Minus,
  X,
  Trash2,
  CheckCircle,
  Lock,
  BarChart3,
  Star,
  Eye,
  EyeOff,
} from "lucide-react";
import { auth, db, storage } from "./firebase";
import {
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  collection,
  addDoc,
  query,
  orderBy,
} from "firebase/firestore";
import { ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage";
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from "firebase/auth";

/**
 * Uploads a photo (File object straight from an <input type="file">) to
 * Firebase Storage and returns its public download URL. `path` should be
 * unique per photo, e.g. `products/abc123/1699999999.jpg`.
 */
async function uploadImageToStorage(file, path) {
  const fileRef = storageRef(storage, path);
  await uploadBytes(fileRef, file);
  return getDownloadURL(fileRef);
}

/** Translates the Firebase Auth error codes we're likely to hit into French. */
function firebaseAuthErrorToFrench(code) {
  switch (code) {
    case "auth/email-already-in-use":
      return "Un compte existe déjà avec cet email.";
    case "auth/invalid-email":
      return "Adresse email invalide.";
    case "auth/weak-password":
      return "Le mot de passe doit faire au moins 6 caractères.";
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return "Email ou mot de passe incorrect.";
    case "auth/too-many-requests":
      return "Trop de tentatives, réessaie dans un instant.";
    default:
      return "Une erreur est survenue. Réessaie.";
  }
}

/**
 * Persists a piece of state to localStorage so it survives page reloads.
 * This is a lightweight solution for prototyping. For a real production app
 * with multiple devices/users, replace this with a real backend
 * (Firebase, Supabase, your own API, etc.) instead.
 */
function usePersistentState(key, initialValue) {
  const [state, setState] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key);
      if (stored !== null) return JSON.parse(stored);
    } catch {
      // ignore parse errors, fall back to initial value
    }
    return typeof initialValue === "function" ? initialValue() : initialValue;
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(state));
    } catch {
      // storage full or unavailable, fail silently
    }
  }, [key, state]);

  return [state, setState];
}

/* ---------- Shared data ---------- */

const products = [
  { id: 1, name: "Eau de parfum Ambre", price: 28000, badge: "-20%", badgeType: "sale", image: null, category: "Parfums", description: "Notes chaudes d'ambre et de vanille, tenue longue durée.", stock: 12 },
  { id: 2, name: "Bougie bois de santal", price: 14500, badge: "Best-seller", badgeType: "featured", image: null, category: "Bougies", description: "Cire naturelle, combustion 45h, senteur boisée apaisante.", stock: 20 },
  { id: 3, name: "Diffuseur fleur de coton", price: 19000, image: null, category: "Diffuseurs", description: "Diffusion douce et continue, idéal pour le salon ou la chambre.", stock: 8 },
  { id: 4, name: "Coffret découverte", price: 42000, image: null, category: "Coffrets", description: "4 miniatures pour découvrir nos meilleures senteurs signature.", stock: 5 },
];
// Pour ajouter une vraie photo, remplis "image" avec une URL ou un import,
// ex: image: "/images/ambre.jpg" ou image: monImportDePhoto

const categories = [
  { id: 1, name: "Parfums", count: 24 },
  { id: 2, name: "Bougies", count: 18 },
  { id: 3, name: "Diffuseurs", count: 9 },
  { id: 4, name: "Coffrets", count: 6 },
  { id: 5, name: "Soins du corps", count: 14 },
  { id: 6, name: "Accessoires", count: 11 },
];

const paymentMethods = [
  { id: "wave", label: "Wave", sub: "Paiement mobile instantané", icon: "wave", color: "#1DAFFF" },
  { id: "orange", label: "Orange Money", sub: "Paiement mobile instantané", icon: "wave", color: "#FF7900" },
  { id: "card", label: "Carte bancaire", sub: "Visa, Mastercard", icon: "card", color: "#4F46E5" },
  { id: "cash", label: "Paiement à la livraison", sub: "Espèces à la réception", icon: "cash", color: "#16A34A" },
];

const deliveryFee = 2000;

const ORDER_STATUS_FLOW = ["En préparation", "En livraison", "Livrée"];

function getStatusStyle(status) {
  if (status === "Livrée") return { bg: "#e6faf8", text: "#00867e" };
  if (status === "En livraison") return { bg: "#eaf2ff", text: "#3b6bd9" };
  return { bg: "#fff6e6", text: "#c47f0a" };
}

/**
 * Processes a payment through the selected provider.
 *
 * IMPORTANT: this is currently a MOCK. It simulates a network call and
 * always succeeds (unless a mobile money method is missing a phone number).
 * Nothing here actually charges anyone.
 *
 * TO GO LIVE WITH WAVE / ORANGE MONEY:
 * 1. Open a merchant account with Wave (https://www.wave.com) and/or Orange
 *    Money Business. They'll give you API credentials (a secret key).
 * 2. NEVER put that secret key in this frontend file — anyone could read it
 *    in the browser. Instead, build a small backend endpoint (Node/Express,
 *    Firebase Function, etc.) that holds the secret key and calls Wave's /
 *    Orange's API on your server.
 * 3. Replace the body of this function with a call to YOUR backend, e.g.:
 *
 *      const res = await fetch("https://your-backend.com/api/pay", {
 *        method: "POST",
 *        headers: { "Content-Type": "application/json" },
 *        body: JSON.stringify({ method, amount, phoneNumber }),
 *      });
 *      const data = await res.json();
 *      if (!data.success) throw new Error(data.message || "Paiement refusé");
 *      return data;
 *
 * 4. Your backend then returns success/failure here, and this screen's logic
 *    (loading state, error message, confirmation) keeps working as-is.
 * 5. For card payments, route similarly through a PCI-compliant processor
 *    (Stripe, PayDunya, CinetPay...) rather than handling card numbers here.
 */
async function processPayment({ method, amount, phoneNumber }) {
  // Simulated network delay so the UI's loading state is visible
  await new Promise((resolve) => setTimeout(resolve, 1500));

  if ((method === "wave" || method === "orange") && !phoneNumber?.trim()) {
    throw new Error("Numéro de téléphone requis pour ce mode de paiement.");
  }

  // TODO: replace everything above with the real backend call described above
  return { success: true, transactionId: `mock-${Date.now()}` };
}
const format = (n) => n.toLocaleString("fr-FR") + " F";
const serif = { fontFamily: "Georgia, serif" };
const heroGradient = "linear-gradient(160deg, #003c39 0%, #00867e 45%, #00c2b8 90%)";
const heroGradientAnimated =
  "linear-gradient(120deg, #003c39, #00867e, #00c2b8, #17d9c4, #00867e, #003c39)";

function AnimatedBackgroundStyles() {
  return (
    <style>{`
      @keyframes heroGradientFlow {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
      }
      @keyframes heroBlobFloat {
        0%, 100% { transform: translate(0, 0) scale(1); }
        50% { transform: translate(14px, -18px) scale(1.12); }
      }
      .hero-animated {
        background-image: linear-gradient(120deg, #003c39, #00867e, #00c2b8, #4bf3e6, #00c2b8, #00867e, #003c39);
        background-size: 300% 300%;
        animation: heroGradientFlow 14s ease infinite;
      }
      .hero-blob {
        animation: heroBlobFloat 7s ease-in-out infinite;
      }
      @keyframes ambientFloat {
        0% { transform: translate(0, 0) scale(1); }
        25% { transform: translate(22px, -26px) scale(1.1); }
        50% { transform: translate(-16px, 16px) scale(0.94); }
        75% { transform: translate(26px, 10px) scale(1.06); }
        100% { transform: translate(0, 0) scale(1); }
      }
    `}</style>
  );
}

const ambientBlobs = [
  { top: "4%", left: "8%", size: 110, color: "#00c2b8", duration: "9s", delay: "0s" },
  { top: "68%", left: "82%", size: 150, color: "#003c39", duration: "12s", delay: "1.4s" },
  { top: "38%", left: "-6%", size: 130, color: "#00867e", duration: "13.5s", delay: "0.6s" },
  { top: "82%", left: "18%", size: 85, color: "#4bf3e6", duration: "8s", delay: "2.2s" },
  { top: "8%", left: "72%", size: 120, color: "#00867e", duration: "10.5s", delay: "3s" },
  { top: "52%", left: "48%", size: 70, color: "#00c2b8", duration: "7.5s", delay: "1s" },
  { top: "22%", left: "38%", size: 60, color: "#003c39", duration: "11s", delay: "2.8s" },
];

function AmbientBackdrop() {
  return (
    <>
      {ambientBlobs.map((b, i) => (
        <div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            top: b.top,
            left: b.left,
            width: b.size,
            height: b.size,
            background: b.color,
            opacity: 0.14,
            animation: `ambientFloat ${b.duration} ease-in-out infinite`,
            animationDelay: b.delay,
          }}
        />
      ))}
    </>
  );
}

/* ---------- Small icon helpers ---------- */

function ProductIcon({ index }) {
  const icons = [
    <path key="a" d="M9 2h6M10 2v5.5L6 15v5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-5l-4-7.5V2" />,
    <path key="b" d="M12 2c1 2 1 3.5 0 5-1-1.5-1-3 0-5ZM9 8h6l1 12H8L9 8Z" />,
    <path key="c" d="M12 2v4M6 8h12l-1 12a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 8Z" />,
    <>
      <rect key="d1" x="4" y="8" width="16" height="12" rx="1" />
      <path key="d2" d="M4 12h16M12 8v12M8 8V6a4 4 0 0 1 8 0v2" />
    </>,
  ];
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      {icons[index % icons.length]}
    </svg>
  );
}

function CategoryIcon({ index }) {
  const icons = [
    <path key="a" d="M9 2h6M10 2v5.5L6 15v5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-5l-4-7.5V2" />,
    <>
      <path key="b1" d="M12 2c1 2 1 3.5 0 5-1-1.5-1-3 0-5Z" />
      <path key="b2" d="M9 8h6l1 12H8L9 8Z" />
    </>,
    <path key="c" d="M12 2v4M6 8h12l-1 12a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 8Z" />,
    <>
      <rect key="d1" x="4" y="8" width="16" height="12" rx="1" />
      <path key="d2" d="M4 12h16M12 8v12M8 8V6a4 4 0 0 1 8 0v2" />
    </>,
    <path key="e" d="M12 3a6 6 0 0 1 6 6c0 4-6 12-6 12s-6-8-6-12a6 6 0 0 1 6-6Z" />,
    <>
      <circle key="f1" cx="9" cy="9" r="2" />
      <path key="f2" d="M3 19v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" />
      <circle key="f3" cx="17" cy="7" r="1.5" />
    </>,
  ];
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      {icons[index % icons.length]}
    </svg>
  );
}

function MethodIcon({ type }) {
  if (type === "card") return <CreditCard size={20} />;
  if (type === "cash") return <Banknote size={20} />;
  return <Smartphone size={20} />;
}

/* ---------- Screens ---------- */

const homeCategories = ["Tout", "Parfums", "Bougies", "Diffuseurs", "Coffrets"];

function HomeScreen({
  onOpenCart,
  categoryFilter,
  onSelectCategory,
  onAddToCart,
  cartCount,
  productImages,
  onAddProductImage,
  vendorLogo,
  onSetVendorLogo,
  productDescriptions,
  onSetProductDescription,
  allProducts,
  onAddProduct,
  stockLevels,
  onOpenDetail,
  favorites,
  onToggleFavorite,
  onOpenFavorites,
  productReviews,
  isVendor,
}) {
  const [editingDescId, setEditingDescId] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [quantities, setQuantities] = useState({});
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");

  const getQty = (id) => quantities[id] ?? 1;
  const setQty = (id, val) => setQuantities((prev) => ({ ...prev, [id]: val }));
  const [newProduct, setNewProduct] = useState({ name: "", price: "", category: "Parfums", stock: "20", id: null });
  const newProductPhoto = newProduct.id ? productImages[newProduct.id]?.[0] : null;

  const getAverageRating = (productId) => {
    const reviews = productReviews[productId] ?? [];
    if (reviews.length === 0) return { average: 0, count: 0 };
    return { average: reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length, count: reviews.length };
  };

  const categoryFiltered =
    categoryFilter === "Tout" ? allProducts : allProducts.filter((p) => p.category === categoryFilter);
  const searchedProducts = searchQuery.trim()
    ? categoryFiltered.filter((p) => {
        const q = searchQuery.trim().toLowerCase();
        const desc = productDescriptions[p.id] ?? p.description ?? "";
        return p.name.toLowerCase().includes(q) || desc.toLowerCase().includes(q);
      })
    : categoryFiltered;

  const filteredProducts = [...searchedProducts].sort((a, b) => {
    if (sortBy === "price_asc") return a.price - b.price;
    if (sortBy === "price_desc") return b.price - a.price;
    if (sortBy === "rating") return getAverageRating(b.id).average - getAverageRating(a.id).average;
    return 0;
  });

  const openAddForm = () => {
    if (!showAddForm) {
      setNewProduct({ name: "", price: "", category: "Parfums", stock: "20", id: `custom-${Date.now()}` });
    }
    setShowAddForm((v) => !v);
  };

  const submitNewProduct = () => {
    if (!newProduct.name.trim() || !newProduct.price || !newProduct.id) return;
    onAddProduct({
      id: newProduct.id,
      name: newProduct.name.trim(),
      price: Number(newProduct.price),
      category: newProduct.category,
      description: "",
      stock: Number(newProduct.stock) || 0,
    });
    setNewProduct({ name: "", price: "", category: "Parfums", stock: "20", id: null });
    setShowAddForm(false);
  };

  const handleNewProductPhoto = (e) => {
    const file = e.target.files[0];
    if (!file || !newProduct.id) return;
    onAddProductImage({ id: newProduct.id, image: null }, file);
  };

  const handleFileChange = (product) => (e) => {
    const file = e.target.files[0];
    if (!file) return;
    onAddProductImage(product, file);
  };

  const handleVendorLogoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    onSetVendorLogo(file);
  };

  return (
    <>
      <div
        className={`relative px-6 pt-7 pb-16 overflow-hidden ${vendorLogo ? "" : "hero-animated"}`}
      >
        {vendorLogo && (
          <>
            <img
              src={vendorLogo}
              alt="Photo boutique"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div
              className="absolute inset-0 pointer-events-none hero-animated"
              style={{ opacity: 0.11 }}
            />
          </>
        )}
        <div
          className="absolute rounded-full pointer-events-none hero-blob"
          style={{
            right: "-60px",
            top: "-40px",
            width: "220px",
            height: "220px",
            background: "radial-gradient(circle at 30% 30%, rgba(255,255,255,0.18), rgba(255,255,255,0) 70%)",
          }}
        />
        <div className="relative z-10 flex items-center justify-between">
          <span className="text-white text-xl tracking-wide" style={serif}>My Store</span>
          <div className="flex gap-2.5">
            {isVendor && (
              <>
                <input
                  type="file"
                  accept="image/*"
                  id="vendor-logo-input"
                  onChange={handleVendorLogoChange}
                  className="hidden"
                />
                <label
                  htmlFor="vendor-logo-input"
                  aria-label={vendorLogo ? "Changer la photo" : "Ajouter une photo"}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white cursor-pointer"
                  style={{ background: "#00c2b8" }}
                >
                  <Camera size={15} />
                </label>
              </>
            )}
            <button
              aria-label="Favoris"
              onClick={onOpenFavorites}
              className="w-8 h-8 rounded-full flex items-center justify-center text-white"
              style={{ background: "#00c2b8" }}
            >
              <Heart size={16} />
            </button>
            <button
              aria-label="Panier"
              onClick={onOpenCart}
              className="relative w-8 h-8 rounded-full flex items-center justify-center text-white"
              style={{ background: "#00c2b8" }}
            >
              <ShoppingBag size={16} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#003c39] text-white text-[9px] font-semibold w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
        <p className="relative z-10 italic text-sm text-white/85 mt-5" style={serif}>édition privée</p>
        <h1 className="relative z-10 text-2xl leading-tight text-white mt-1.5 max-w-[220px]" style={serif}>
          Des senteurs qui racontent une histoire
        </h1>

        {isVendor && !vendorLogo && (
          <label
            htmlFor="vendor-logo-input"
            className="relative z-10 mt-3 inline-flex items-center gap-1.5 text-[11px] text-white/80 cursor-pointer underline underline-offset-2"
          >
            <Camera size={13} />
            Ajouter une photo de la boutique
          </label>
        )}

        <div
          className="relative z-20 -mb-9 mt-5 rounded-2xl px-4 py-3 flex items-center gap-2.5 text-[13px] shadow-lg"
          style={{ background: "#00c2b8" }}
        >
          <Search size={15} className="opacity-80 flex-shrink-0 text-white" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher un parfum"
            className="flex-1 bg-transparent outline-none text-white placeholder-white/70"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} aria-label="Effacer la recherche">
              <X size={14} className="text-white/80" />
            </button>
          )}
        </div>
      </div>

      <div className="px-6 pt-12 pb-5">
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-[17px] font-medium text-[#0c1f1d]" style={serif}>Sélection du moment</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onSelectCategory("Tout");
                setSearchQuery("");
              }}
              className="text-xs text-[#00867e]"
            >
              Voir tout
            </button>
            {isVendor && (
              <button
                onClick={openAddForm}
                aria-label="Ajouter un nouveau produit"
                className="w-6 h-6 rounded-full flex items-center justify-center text-white flex-shrink-0"
                style={{ background: "#00c2b8" }}
              >
                <Plus size={14} />
              </button>
            )}
          </div>
        </div>

        {isVendor && showAddForm && (
          <div className="bg-white border border-neutral-200 rounded-2xl p-3.5 mb-4">
            <div className="flex items-center justify-between mb-2.5">
              <p className="text-xs font-medium text-[#0c1f1d]">Nouveau produit</p>
              <button onClick={() => setShowAddForm(false)} aria-label="Fermer">
                <X size={14} className="text-neutral-400" />
              </button>
            </div>
            <div className="flex items-center gap-3 mb-2.5">
              <div
                className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden"
                style={!newProductPhoto ? { background: "#00c2b8" } : undefined}
              >
                {newProductPhoto ? (
                  <img src={newProductPhoto} alt="Aperçu" className="w-full h-full object-cover" />
                ) : (
                  <Camera size={18} className="text-white" />
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                id="new-product-photo"
                onChange={handleNewProductPhoto}
                className="hidden"
              />
              <label
                htmlFor="new-product-photo"
                className="text-[11px] text-[#00867e] underline underline-offset-2 cursor-pointer"
              >
                {newProductPhoto ? "Changer la photo" : "Ajouter une photo"}
              </label>
            </div>
            <input
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              placeholder="Nom du produit"
              className="w-full text-xs border border-neutral-200 rounded-lg px-3 py-2 mb-2 outline-none"
            />
            <input
              value={newProduct.price}
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value.replace(/[^0-9]/g, "") })}
              placeholder="Prix (F CFA)"
              inputMode="numeric"
              className="w-full text-xs border border-neutral-200 rounded-lg px-3 py-2 mb-2 outline-none"
            />
            <input
              value={newProduct.stock}
              onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value.replace(/[^0-9]/g, "") })}
              placeholder="Stock initial"
              inputMode="numeric"
              className="w-full text-xs border border-neutral-200 rounded-lg px-3 py-2 mb-2 outline-none"
            />
            <div className="flex gap-1.5 mb-3 overflow-x-auto">
              {homeCategories.slice(1).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setNewProduct({ ...newProduct, category: cat })}
                  className={`text-[10px] px-2.5 py-1 rounded-full whitespace-nowrap border ${
                    newProduct.category === cat
                      ? "bg-[#00c2b8] text-white border-[#00c2b8]"
                      : "border-neutral-300 text-neutral-500"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
            <button
              onClick={submitNewProduct}
              className="w-full bg-[#0c1f1d] text-white text-xs font-medium py-2.5 rounded-xl"
            >
              Ajouter le produit
            </button>
          </div>
        )}

        <div className="flex gap-2 mb-5 overflow-x-auto">
          {homeCategories.map((cat) => {
            const isActive = categoryFilter === cat;
            return (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`text-[11px] px-3.5 py-1.5 rounded-full whitespace-nowrap border transition-colors ${
                  isActive ? "bg-[#00c2b8] text-white border-[#00c2b8]" : "border-neutral-300 text-neutral-500"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        <div className="flex gap-1.5 mb-4 overflow-x-auto">
          {[
            { id: "recent", label: "Récent" },
            { id: "price_asc", label: "Prix ↑" },
            { id: "price_desc", label: "Prix ↓" },
            { id: "rating", label: "Mieux notés" },
          ].map((option) => (
            <button
              key={option.id}
              onClick={() => setSortBy(option.id)}
              className={`text-[10px] px-2.5 py-1 rounded-full whitespace-nowrap border ${
                sortBy === option.id ? "bg-[#0c1f1d] text-white border-[#0c1f1d]" : "border-neutral-200 text-neutral-400"
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="flex flex-col items-center py-10 gap-2">
            <Search size={28} className="text-neutral-200" />
            <p className="text-xs text-neutral-400 text-center">
              {searchQuery.trim()
                ? `Aucun résultat pour "${searchQuery.trim()}".`
                : "Aucun produit dans cette catégorie pour l'instant."}
            </p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          {filteredProducts.map((product, i) => {
            const gallery = productImages[product.id];
            const displayImage = gallery && gallery.length > 0 ? gallery[0] : product.image;
            return (
              <div
                key={product.id}
                onClick={() => onOpenDetail(product)}
                className="bg-white rounded-2xl overflow-hidden border border-neutral-200 cursor-pointer"
              >
                <div
                  className="aspect-square w-full flex flex-col items-center justify-center relative text-white overflow-hidden gap-1.5"
                  style={!displayImage ? { background: "#00c2b8" } : undefined}
                >
                  {product.badge && (
                    <span
                      className={`absolute top-2 left-2 z-10 text-white text-[9px] font-semibold px-2 py-1 rounded-md tracking-wide ${
                        product.badgeType === "featured" ? "bg-[#003c39]" : "bg-[#00c2b8]"
                      }`}
                    >
                      {product.badge}
                    </span>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(product.id);
                    }}
                    aria-label="Ajouter aux favoris"
                    className="absolute top-2 right-2 z-10 w-6 h-6 rounded-full bg-white/90 flex items-center justify-center"
                  >
                    <Heart
                      size={12}
                      className={favorites.includes(product.id) ? "text-red-500" : "text-neutral-400"}
                      fill={favorites.includes(product.id) ? "currentColor" : "none"}
                    />
                  </button>
                  {displayImage ? (
                    <img
                      src={displayImage}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : isVendor ? (
                    <>
                      <ProductIcon index={i} />
                      <input
                        type="file"
                        accept="image/*"
                        id={`photo-${product.id}`}
                        onChange={handleFileChange(product)}
                        className="hidden"
                      />
                      <label
                        htmlFor={`photo-${product.id}`}
                        onClick={(e) => e.stopPropagation()}
                        className="flex items-center gap-1 text-[10px] text-[#00c2b8] bg-white/90 px-2 py-1 rounded-full cursor-pointer"
                      >
                        <Camera size={11} />
                        Ajouter photo
                      </label>
                    </>
                  ) : (
                    <ProductIcon index={i} />
                  )}
                </div>
                <div className="p-3">
                  <p className="text-xs text-neutral-700 mb-1">{product.name}</p>

                  {!isVendor ? (
                    <p className="text-[10.5px] text-neutral-400 leading-snug mb-2 line-clamp-2">
                      {productDescriptions[product.id] ?? product.description}
                    </p>
                  ) : editingDescId === product.id ? (
                    <textarea
                      autoFocus
                      onClick={(e) => e.stopPropagation()}
                      defaultValue={productDescriptions[product.id] ?? product.description}
                      onBlur={(e) => {
                        onSetProductDescription(product.id, e.target.value);
                        setEditingDescId(null);
                      }}
                      className="w-full text-[10.5px] text-neutral-600 leading-snug mb-2 border border-neutral-200 rounded-md p-1.5 outline-none resize-none"
                      rows={2}
                    />
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingDescId(product.id);
                      }}
                      className="flex items-start gap-1 text-left mb-2 w-full group"
                    >
                      <p className="text-[10.5px] text-neutral-400 leading-snug line-clamp-2">
                        {productDescriptions[product.id] ?? product.description}
                      </p>
                      <Pencil size={10} className="text-neutral-300 flex-shrink-0 mt-0.5 group-hover:text-[#00c2b8]" />
                    </button>
                  )}

                  <p className="text-[15px] text-[#0c1f1d] mb-1" style={serif}>{format(product.price)}</p>

                  {(() => {
                    const { average, count } = getAverageRating(product.id);
                    if (count === 0) return null;
                    return (
                      <div className="flex items-center gap-1 mb-1.5">
                        <StarRating value={average} size={10} />
                        <span className="text-[9px] text-neutral-400">({count})</span>
                      </div>
                    );
                  })()}

                  {(() => {
                    const remaining = stockLevels[product.id] ?? 0;
                    const qty = getQty(product.id);
                    return (
                      <>
                        <p className={`text-[10px] mb-2 ${remaining === 0 ? "text-red-500" : "text-neutral-400"}`}>
                          {remaining === 0 ? "Rupture de stock" : `${remaining} en stock`}
                        </p>

                        {remaining > 0 && (
                          <div className="flex items-center justify-between mb-2 bg-neutral-100 rounded-lg px-1.5 py-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setQty(product.id, Math.max(1, qty - 1));
                              }}
                              disabled={qty <= 1}
                              aria-label="Diminuer la quantité"
                              className="w-5 h-5 rounded flex items-center justify-center text-neutral-500 disabled:opacity-30"
                            >
                              <Minus size={11} />
                            </button>
                            <span className="text-[11px] text-[#0c1f1d] font-medium">{qty}</span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setQty(product.id, Math.min(remaining, qty + 1));
                              }}
                              disabled={qty >= remaining}
                              aria-label="Augmenter la quantité"
                              className="w-5 h-5 rounded flex items-center justify-center text-neutral-500 disabled:opacity-30"
                            >
                              <Plus size={11} />
                            </button>
                          </div>
                        )}
                      </>
                    );
                  })()}

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddToCart(product, getQty(product.id));
                      setQty(product.id, 1);
                    }}
                    disabled={(stockLevels[product.id] ?? 0) === 0}
                    className={`w-full text-[11px] font-medium py-2 rounded-[10px] ${
                      (stockLevels[product.id] ?? 0) === 0
                        ? "bg-neutral-200 text-neutral-400"
                        : "bg-[#0c1f1d] text-white"
                    }`}
                  >
                    {(stockLevels[product.id] ?? 0) === 0 ? "Épuisé" : "Ajouter"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

function CategoriesScreen({ onSelectCategory, allProducts }) {
  const [searchQuery, setSearchQuery] = useState("");
  const filteredCategories = categories.filter((cat) =>
    cat.name.toLowerCase().includes(searchQuery.trim().toLowerCase())
  );

  return (
    <>
      <div className="px-6 pt-7 pb-8 hero-animated">
        <h1 className="text-white text-lg" style={serif}>Catégories</h1>
        <div className="mt-5 bg-white rounded-2xl px-4 py-3 flex items-center gap-2.5 text-[13px] text-neutral-500">
          <Search size={15} className="opacity-60 flex-shrink-0" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une catégorie"
            className="flex-1 outline-none bg-transparent"
          />
        </div>
      </div>
      <div className="px-6 py-5 flex flex-col gap-3">
        {filteredCategories.length === 0 && (
          <div className="flex flex-col items-center py-10 gap-2">
            <Search size={28} className="text-neutral-200" />
            <p className="text-xs text-neutral-400 text-center">Aucun résultat pour "{searchQuery}".</p>
          </div>
        )}
        {filteredCategories.map((cat) => {
          const i = categories.indexOf(cat);
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.name)}
              className="flex items-center gap-4 bg-white border border-neutral-200 rounded-2xl px-4 py-3 text-left active:bg-neutral-50"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-white flex-shrink-0"
                style={{ background: "#00c2b8" }}
              >
                <CategoryIcon index={i} />
              </div>
              <div className="flex-1">
                <p className="text-sm text-[#0c1f1d]" style={serif}>{cat.name}</p>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {allProducts.filter((p) => p.category === cat.name).length} produits
                </p>
              </div>
              <ChevronLeft size={16} className="rotate-180 text-neutral-300" />
            </button>
          );
        })}
      </div>
    </>
  );
}

function FavoritesScreen({
  favoriteProducts,
  productImages,
  stockLevels,
  onToggleFavorite,
  onAddToCart,
  onOpenDetail,
  onBack,
}) {
  return (
    <>
      <div className="px-6 pt-7 pb-8 flex items-center gap-3 hero-animated">
        <button
          onClick={onBack}
          aria-label="Retour"
          className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center text-white flex-shrink-0"
        >
          <ChevronLeft size={18} />
        </button>
        <h1 className="text-white text-lg" style={serif}>Mes favoris</h1>
      </div>

      <div className="px-6 py-5">
        {favoriteProducts.length === 0 ? (
          <div className="flex flex-col items-center py-10 gap-2">
            <Heart size={28} className="text-neutral-200" />
            <p className="text-xs text-neutral-400 text-center">
              Aucun favori pour l'instant. Touche le cœur sur un produit pour l'ajouter ici.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {favoriteProducts.map((product, i) => {
              const gallery = productImages[product.id];
              const displayImage = gallery && gallery.length > 0 ? gallery[0] : product.image;
              const remaining = stockLevels[product.id] ?? 0;
              return (
                <div
                  key={product.id}
                  onClick={() => onOpenDetail(product)}
                  className="bg-white rounded-2xl overflow-hidden border border-neutral-200 cursor-pointer"
                >
                  <div
                    className="aspect-square w-full flex items-center justify-center relative text-white overflow-hidden"
                    style={!displayImage ? { background: "#00c2b8" } : undefined}
                  >
                    {displayImage ? (
                      <img src={displayImage} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <ProductIcon index={i} />
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(product.id);
                      }}
                      aria-label="Retirer des favoris"
                      className="absolute top-2 right-2 z-10 w-6 h-6 rounded-full bg-white/90 flex items-center justify-center"
                    >
                      <Heart size={12} className="text-red-500" fill="currentColor" />
                    </button>
                  </div>
                  <div className="p-3">
                    <p className="text-xs text-neutral-700 mb-1">{product.name}</p>
                    <p className="text-[15px] text-[#0c1f1d] mb-2" style={serif}>{format(product.price)}</p>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddToCart(product, 1);
                      }}
                      disabled={remaining === 0}
                      className={`w-full text-[11px] font-medium py-2 rounded-[10px] ${
                        remaining === 0 ? "bg-neutral-200 text-neutral-400" : "bg-[#0c1f1d] text-white"
                      }`}
                    >
                      {remaining === 0 ? "Épuisé" : "Ajouter"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}

function StarRating({ value, onChange, size = 16 }) {
  const stars = [1, 2, 3, 4, 5];
  return (
    <div className="flex gap-0.5">
      {stars.map((n) => (
        <button
          key={n}
          type="button"
          disabled={!onChange}
          onClick={() => onChange && onChange(n)}
          aria-label={`${n} étoile${n > 1 ? "s" : ""}`}
          className={onChange ? "cursor-pointer" : "cursor-default"}
        >
          <Star
            size={size}
            className={n <= Math.round(value) ? "text-[#00c2b8]" : "text-neutral-200"}
            fill={n <= Math.round(value) ? "currentColor" : "none"}
          />
        </button>
      ))}
    </div>
  );
}

function ProductDetailScreen({
  product,
  stockLevels,
  productImages,
  onAddProductImage,
  onRemoveProductImage,
  productDescriptions,
  onSetProductDescription,
  onAddToCart,
  onUpdateProduct,
  onDeleteProduct,
  reviews,
  onAddReview,
  reviewerName,
  isVendor,
  onBack,
}) {
  const [qty, setQty] = useState(1);
  const [editingDesc, setEditingDesc] = useState(false);
  const [editingInfo, setEditingInfo] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState("");
  const [infoForm, setInfoForm] = useState(
    product ? { name: product.name, price: String(product.price), category: product.category } : {}
  );

  if (!product) {
    return (
      <div className="px-6 py-14 text-center text-sm text-neutral-400">
        Produit introuvable.
        <button onClick={onBack} className="block mx-auto mt-4 text-[#00c2b8] underline">
          Retour
        </button>
      </div>
    );
  }

  const images = productImages[product.id] ?? (product.image ? [product.image] : []);
  const safeIndex = Math.min(activeImageIndex, Math.max(images.length - 1, 0));
  const currentImage = images[safeIndex];
  const remaining = stockLevels[product.id] ?? 0;
  const description = productDescriptions[product.id] ?? product.description;
  const averageRating = reviews.length
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  const submitReview = () => {
    if (!newComment.trim()) return;
    onAddReview(product.id, {
      id: `review-${Date.now()}`,
      author: reviewerName || "Client",
      rating: newRating,
      comment: newComment.trim(),
      date: new Date().toISOString(),
    });
    setNewComment("");
    setNewRating(5);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    onAddProductImage(product, file);
    setActiveImageIndex(images.length);
  };

  const handleRemoveCurrentImage = () => {
    onRemoveProductImage(product, safeIndex);
    setActiveImageIndex(Math.max(safeIndex - 1, 0));
  };

  return (
    <>
      <div className="px-6 pt-7 pb-4 flex items-center gap-3 hero-animated">
        <button
          onClick={onBack}
          aria-label="Retour"
          className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center text-white flex-shrink-0"
        >
          <ChevronLeft size={18} />
        </button>
        <h1 className="text-white text-base truncate" style={serif}>{product.name}</h1>
      </div>

      <div className="p-6">
        <div
          className="aspect-square w-full rounded-2xl overflow-hidden relative mb-3 flex flex-col items-center justify-center gap-2"
          style={!currentImage ? { background: "#00c2b8" } : undefined}
        >
          {currentImage ? (
            <img src={currentImage} alt={product.name} className="w-full h-full object-cover" />
          ) : (
            <Camera size={30} className="text-white" />
          )}
          {isVendor && (
            <>
              <input
                type="file"
                accept="image/*"
                id={`detail-photo-${product.id}`}
                onChange={handleFileChange}
                className="hidden"
              />
              <label
                htmlFor={`detail-photo-${product.id}`}
                className={`absolute bottom-3 right-3 flex items-center gap-1 text-[11px] px-2.5 py-1.5 rounded-full cursor-pointer ${
                  currentImage ? "bg-white/90 text-[#00867e]" : "bg-white/80 text-[#00c2b8]"
                }`}
              >
                <Camera size={12} />
                Ajouter photo
              </label>
              {currentImage && (
                <button
                  onClick={handleRemoveCurrentImage}
                  aria-label="Supprimer cette photo"
                  className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center text-red-500"
                >
                  <Trash2 size={13} />
                </button>
              )}
            </>
          )}
        </div>

        {images.length > 0 && (
          <div className="flex gap-2 mb-5 overflow-x-auto">
            {images.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImageIndex(i)}
                className={`w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 border-2 ${
                  i === safeIndex ? "border-[#00c2b8]" : "border-transparent"
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
            {isVendor && (
              <label
                htmlFor={`detail-photo-${product.id}`}
                className="w-14 h-14 rounded-lg flex-shrink-0 border border-dashed border-neutral-300 flex items-center justify-center text-neutral-400 cursor-pointer"
              >
                <Plus size={16} />
              </label>
            )}
          </div>
        )}

        {editingInfo ? (
          <div className="mb-5">
            <input
              value={infoForm.name}
              onChange={(e) => setInfoForm({ ...infoForm, name: e.target.value })}
              placeholder="Nom du produit"
              className="w-full text-sm border border-neutral-200 rounded-lg px-3 py-2 mb-2 outline-none"
            />
            <input
              value={infoForm.price}
              onChange={(e) => setInfoForm({ ...infoForm, price: e.target.value.replace(/[^0-9]/g, "") })}
              placeholder="Prix (F CFA)"
              inputMode="numeric"
              className="w-full text-sm border border-neutral-200 rounded-lg px-3 py-2 mb-2 outline-none"
            />
            <div className="flex gap-1.5 mb-3 overflow-x-auto">
              {homeCategories.slice(1).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setInfoForm({ ...infoForm, category: cat })}
                  className={`text-[10px] px-2.5 py-1 rounded-full whitespace-nowrap border ${
                    infoForm.category === cat
                      ? "bg-[#00c2b8] text-white border-[#00c2b8]"
                      : "border-neutral-300 text-neutral-500"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setEditingInfo(false)}
                className="flex-1 text-xs font-medium py-2.5 rounded-xl border border-neutral-300 text-neutral-500"
              >
                Annuler
              </button>
              <button
                onClick={() => {
                  onUpdateProduct(product.id, {
                    name: infoForm.name.trim() || product.name,
                    price: Number(infoForm.price) || product.price,
                    category: infoForm.category,
                  });
                  setEditingInfo(false);
                }}
                className="flex-1 bg-[#0c1f1d] text-white text-xs font-medium py-2.5 rounded-xl"
              >
                Enregistrer
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between mb-1">
            <p className="text-xl text-[#0c1f1d]" style={serif}>{format(product.price)}</p>
            {isVendor && (
              <button
                onClick={() => {
                  setInfoForm({ name: product.name, price: String(product.price), category: product.category });
                  setEditingInfo(true);
                }}
                aria-label="Modifier le produit"
                className="text-[#00c2b8]"
              >
                <Pencil size={14} />
              </button>
            )}
          </div>
        )}
        <p className={`text-xs mb-2 ${remaining === 0 ? "text-red-500" : "text-neutral-400"}`}>
          {remaining === 0 ? "Rupture de stock" : `${remaining} en stock`}
        </p>

        <div className="flex items-center gap-2 mb-5">
          <StarRating value={averageRating} size={14} />
          <span className="text-xs text-neutral-400">
            {reviews.length > 0 ? `${averageRating.toFixed(1)} (${reviews.length} avis)` : "Aucun avis pour l'instant"}
          </span>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-medium text-[#0c1f1d]">Description</p>
            {isVendor && !editingDesc && (
              <button onClick={() => setEditingDesc(true)} aria-label="Modifier la description" className="text-[#00c2b8]">
                <Pencil size={13} />
              </button>
            )}
          </div>
          {editingDesc ? (
            <textarea
              autoFocus
              defaultValue={description}
              onBlur={(e) => {
                onSetProductDescription(product.id, e.target.value);
                setEditingDesc(false);
              }}
              className="w-full text-sm text-neutral-600 border border-neutral-200 rounded-xl p-3 outline-none resize-none"
              rows={4}
            />
          ) : (
            <p className="text-sm text-neutral-500 leading-relaxed">
              {description || "Aucune description pour l'instant."}
            </p>
          )}
        </div>

        {remaining > 0 && (
          <div className="flex items-center justify-between mb-4 bg-neutral-100 rounded-xl px-3 py-2 w-32">
            <button
              onClick={() => setQty(Math.max(1, qty - 1))}
              disabled={qty <= 1}
              aria-label="Diminuer la quantité"
              className="w-6 h-6 flex items-center justify-center text-neutral-500 disabled:opacity-30"
            >
              <Minus size={13} />
            </button>
            <span className="text-sm font-medium text-[#0c1f1d]">{qty}</span>
            <button
              onClick={() => setQty(Math.min(remaining, qty + 1))}
              disabled={qty >= remaining}
              aria-label="Augmenter la quantité"
              className="w-6 h-6 flex items-center justify-center text-neutral-500 disabled:opacity-30"
            >
              <Plus size={13} />
            </button>
          </div>
        )}

        <button
          onClick={() => {
            onAddToCart(product, qty);
            setQty(1);
          }}
          disabled={remaining === 0}
          className={`w-full text-sm font-medium py-3.5 rounded-2xl ${
            remaining === 0 ? "bg-neutral-200 text-neutral-400" : "bg-[#0c1f1d] text-white"
          }`}
        >
          {remaining === 0 ? "Épuisé" : "Ajouter au panier"}
        </button>

        <div className="mt-6 pt-5 border-t border-neutral-200">
          <p className="text-xs font-medium text-[#0c1f1d] mb-3">Avis clients</p>

          {reviews.length === 0 ? (
            <p className="text-xs text-neutral-400 mb-4">Sois le premier à donner ton avis.</p>
          ) : (
            <div className="flex flex-col gap-3 mb-4">
              {reviews.map((review) => (
                <div key={review.id} className="bg-neutral-50 border border-neutral-200 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-medium text-[#0c1f1d]">{review.author}</p>
                    <StarRating value={review.rating} size={12} />
                  </div>
                  <p className="text-xs text-neutral-500 leading-relaxed">{review.comment}</p>
                  <p className="text-[10px] text-neutral-300 mt-1">
                    {new Date(review.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                  </p>
                </div>
              ))}
            </div>
          )}

          <div className="bg-white border border-neutral-200 rounded-2xl p-3.5">
            <p className="text-xs text-neutral-400 mb-2">Laisser un avis</p>
            <StarRating value={newRating} onChange={setNewRating} size={20} />
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Qu'as-tu pensé de ce produit ?"
              className="w-full text-sm text-neutral-600 border border-neutral-200 rounded-lg p-2.5 mt-3 outline-none resize-none"
              rows={2}
            />
            <button
              onClick={submitReview}
              className="w-full bg-[#0c1f1d] text-white text-xs font-medium py-2.5 rounded-xl mt-2"
            >
              Publier l'avis
            </button>
          </div>
        </div>

        {isVendor && (
          <div className="mt-6 pt-5 border-t border-neutral-200">
            {confirmingDelete ? (
              <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                <p className="text-sm text-red-600 mb-3">Supprimer définitivement ce produit ?</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setConfirmingDelete(false)}
                    className="flex-1 text-xs font-medium py-2.5 rounded-xl border border-neutral-300 text-neutral-500"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={() => {
                      onDeleteProduct(product.id);
                      onBack();
                    }}
                    className="flex-1 bg-red-500 text-white text-xs font-medium py-2.5 rounded-xl"
                  >
                    Oui, supprimer
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setConfirmingDelete(true)}
                className="w-full flex items-center justify-center gap-2 text-sm text-red-500 py-2"
              >
                <Trash2 size={15} />
                Supprimer ce produit
              </button>
            )}
          </div>
        )}
      </div>
    </>
  );
}

function PaymentScreen({ cart, onPay, onUpdateQty, stockLevels, orderConfirmed, confirmedTotal, onDismissConfirmation, isLoggedIn, onRequireAuth }) {
  const [selected, setSelected] = useState(paymentMethods[0].id);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState(null);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const total = cart.length > 0 ? subtotal + deliveryFee : 0;
  const needsPhoneNumber = selected === "wave" || selected === "orange";

  const handlePay = async () => {
    if (!isLoggedIn) {
      onRequireAuth();
      return;
    }
    setPaymentError(null);
    setIsProcessing(true);
    try {
      await processPayment({ method: selected, amount: total, phoneNumber });
      onPay(selected);
    } catch (err) {
      setPaymentError(err.message || "Le paiement a échoué. Réessaie.");
    } finally {
      setIsProcessing(false);
    }
  };

  if (orderConfirmed) {
    return (
      <>
        <div className="px-6 pt-7 pb-8 hero-animated">
          <h1 className="text-white text-lg" style={serif}>Paiement</h1>
        </div>
        <div className="px-6 py-14 flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ background: "#00c2b8" }}>
            <CheckCircle size={30} className="text-white" />
          </div>
          <h2 className="text-lg text-[#0c1f1d] mb-1.5" style={serif}>Commande confirmée ✅</h2>
          <p className="text-sm text-neutral-400 mb-6">
            Merci pour ta commande de {format(confirmedTotal)}. Tu recevras une confirmation sous peu.
          </p>
          <button
            onClick={onDismissConfirmation}
            className="bg-[#0c1f1d] text-white text-sm font-medium px-6 py-3 rounded-2xl"
          >
            Continuer mes achats
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="px-6 pt-7 pb-8 hero-animated">
        <h1 className="text-white text-lg" style={serif}>Paiement</h1>
      </div>

      <div className="px-6 py-5">
        <div className="bg-white border border-neutral-200 rounded-2xl p-4 mb-5">
          <p className="text-xs text-neutral-400 mb-3">Récapitulatif</p>
          {cart.length === 0 ? (
            <div className="flex flex-col items-center py-4 gap-2">
              <ShoppingBag size={26} className="text-neutral-200" />
              <p className="text-sm text-neutral-400">Ton panier est vide pour l'instant.</p>
            </div>
          ) : (
            <>
              {cart.map((item) => {
                const available = stockLevels[item.id] ?? 0;
                return (
                  <div key={item.id} className="flex items-center justify-between text-sm text-[#0c1f1d] mb-3 gap-2">
                    <span className="flex-1">{item.name}</span>

                    <div className="flex items-center gap-1 bg-neutral-100 rounded-lg px-1 py-1 flex-shrink-0">
                      <button
                        onClick={() => onUpdateQty(item.id, item.qty - 1)}
                        aria-label="Diminuer la quantité"
                        className="w-5 h-5 rounded flex items-center justify-center text-neutral-500"
                      >
                        <Minus size={11} />
                      </button>
                      <span className="text-xs font-medium w-4 text-center">{item.qty}</span>
                      <button
                        onClick={() => onUpdateQty(item.id, item.qty + 1)}
                        disabled={item.qty >= available}
                        aria-label="Augmenter la quantité"
                        className="w-5 h-5 rounded flex items-center justify-center text-neutral-500 disabled:opacity-30"
                      >
                        <Plus size={11} />
                      </button>
                    </div>

                    <span className="w-16 text-right flex-shrink-0">{format(item.price * item.qty)}</span>

                    <button
                      onClick={() => onUpdateQty(item.id, 0)}
                      aria-label="Retirer du panier"
                      className="text-neutral-300 flex-shrink-0"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                );
              })}
              <div className="border-t border-neutral-200 mt-2 pt-2 flex justify-between text-sm text-neutral-500">
                <span>Livraison</span>
                <span>{format(deliveryFee)}</span>
              </div>
            </>
          )}
          <div className="flex justify-between mt-2 pt-2 border-t border-neutral-200">
            <span className="text-sm font-medium text-[#0c1f1d]">Total</span>
            <span className="text-base" style={serif}>{format(total)}</span>
          </div>
        </div>

        <p className="text-xs text-neutral-400 mb-3">Mode de paiement</p>
        <div className="flex flex-col gap-2.5 mb-4">
          {paymentMethods.map((method) => {
            const isActive = selected === method.id;
            return (
              <button
                key={method.id}
                onClick={() => {
                  setSelected(method.id);
                  setPaymentError(null);
                }}
                className="flex items-center gap-3 rounded-2xl px-4 py-3 border text-left"
                style={
                  isActive
                    ? { borderColor: method.color, background: `${method.color}14` }
                    : { borderColor: "#e5e5e5", background: "#ffffff" }
                }
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={isActive ? { background: method.color, color: "#ffffff" } : { background: "#f5f5f5", color: "#737373" }}
                >
                  <MethodIcon type={method.icon} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-[#0c1f1d]">{method.label}</p>
                  <p className="text-xs text-neutral-400 mt-0.5">{method.sub}</p>
                </div>
                {isActive && (
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: method.color }}
                  >
                    <Check size={12} className="text-white" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {needsPhoneNumber && (
          <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3 mb-4">
            <Smartphone size={16} className="text-neutral-400 flex-shrink-0" />
            <input
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="Numéro Wave / Orange Money"
              inputMode="tel"
              className="flex-1 text-sm outline-none bg-transparent"
            />
          </div>
        )}

        {paymentError && (
          <p className="text-xs text-red-500 mb-4">{paymentError}</p>
        )}

        <button
          disabled={cart.length === 0 || isProcessing}
          onClick={handlePay}
          className={`w-full text-sm font-medium py-3.5 rounded-2xl ${
            cart.length === 0
              ? "bg-[#e6faf8] text-[#00867e]"
              : isProcessing
              ? "bg-neutral-200 text-neutral-400"
              : "bg-[#0c1f1d] text-white"
          }`}
        >
          {isProcessing
            ? "Traitement en cours..."
            : cart.length === 0
            ? "Panier vide"
            : !isLoggedIn
            ? "Se connecter pour payer"
            : `Payer ${format(total)}`}
        </button>
      </div>
    </>
  );
}

function OrdersScreen({ orders, onBack, onAdvanceStatus, isVendor }) {
  return (
    <>
      <div className="px-6 pt-7 pb-8 flex items-center gap-3 hero-animated">
        <button
          onClick={onBack}
          aria-label="Retour"
          className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center text-white flex-shrink-0"
        >
          <ChevronLeft size={18} />
        </button>
        <h1 className="text-white text-lg" style={serif}>Mes commandes</h1>
      </div>

      <div className="px-6 py-5">
        {orders.length === 0 ? (
          <div className="flex flex-col items-center py-10 gap-2">
            <Package size={28} className="text-neutral-200" />
            <p className="text-xs text-neutral-400 text-center">Aucune commande pour l'instant.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {orders.map((order) => {
              const methodLabel = paymentMethods.find((m) => m.id === order.method)?.label ?? order.method;
              const formattedDate = new Date(order.date).toLocaleDateString("fr-FR", {
                day: "numeric",
                month: "long",
                year: "numeric",
              });
              const status = order.status ?? ORDER_STATUS_FLOW[0];
              const statusStyle = getStatusStyle(status);
              const isFinal = status === ORDER_STATUS_FLOW[ORDER_STATUS_FLOW.length - 1];
              return (
                <div key={order.id} className="bg-white border border-neutral-200 rounded-2xl p-4">
                  <div className="flex items-center justify-between mb-2.5">
                    <p className="text-xs text-neutral-400">{formattedDate}</p>
                    <span
                      className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                      style={{ background: statusStyle.bg, color: statusStyle.text }}
                    >
                      {status}
                    </span>
                  </div>
                  {order.items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm text-[#0c1f1d] mb-1">
                      <span>{item.name} <span className="text-neutral-400">x{item.qty}</span></span>
                      <span>{format(item.price * item.qty)}</span>
                    </div>
                  ))}
                  <div className="border-t border-neutral-200 mt-2 pt-2 flex justify-between text-sm">
                    <span className="font-medium text-[#0c1f1d]">Total</span>
                    <span className="font-medium text-[#0c1f1d]">{format(order.total)}</span>
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1.5 mb-2.5">Payé via {methodLabel}</p>
                  {isVendor && !isFinal && (
                    <button
                      onClick={() => onAdvanceStatus(order.id)}
                      className="w-full text-xs font-medium py-2 rounded-xl border border-neutral-300 text-neutral-600"
                    >
                      Marquer comme "{ORDER_STATUS_FLOW[ORDER_STATUS_FLOW.indexOf(status) + 1]}"
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}

function AuthScreen({ onAuthSuccess, onSkip }) {
  const [mode, setMode] = useState("login");
  const [contactMethod, setContactMethod] = useState("email");
  const [role, setRole] = useState("customer");
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [error, setError] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const submit = async () => {
    if (mode === "signup" && !form.name.trim()) {
      setError("Le nom complet est requis.");
      return;
    }
    if (contactMethod === "email" && !form.email.trim()) {
      setError("L'adresse email est requise.");
      return;
    }
    if (contactMethod === "email" && form.email.trim() && !form.email.includes("@")) {
      setError("Adresse email invalide.");
      return;
    }
    if (contactMethod === "phone" && !form.phone.trim()) {
      setError("Le numéro de téléphone est requis.");
      return;
    }
    if (!form.password.trim()) {
      setError("Le mot de passe est requis.");
      return;
    }
    if (mode === "signup" && form.password.trim().length < 6) {
      setError("Le mot de passe doit faire au moins 6 caractères.");
      return;
    }
    setError(null);
    setSubmitting(true);

    // Firebase Auth's email/password method needs an email even for
    // "phone" sign-up — we build an internal one from the phone number.
    // (Real SMS-based phone auth is a separate, heavier Firebase feature.)
    const effectiveEmail =
      contactMethod === "email" ? form.email.trim() : `${form.phone.trim().replace(/\D/g, "")}@mystore.local`;

    try {
      if (mode === "signup") {
        const credential = await createUserWithEmailAndPassword(auth, effectiveEmail, form.password);
        await updateProfile(credential.user, { displayName: form.name.trim() });
        await setDoc(doc(db, "users", credential.user.uid), {
          name: form.name.trim(),
          email: contactMethod === "email" ? form.email.trim() : "",
          phone: form.phone.trim(),
          address: "",
          role,
        });
      } else {
        await signInWithEmailAndPassword(auth, effectiveEmail, form.password);
      }
      onAuthSuccess();
    } catch (err) {
      setError(firebaseAuthErrorToFrench(err.code));
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full flex justify-center bg-neutral-100 p-6 relative overflow-hidden">
      <AnimatedBackgroundStyles />
      <AmbientBackdrop />
      <div className="w-[360px] rounded-[36px] overflow-hidden bg-[#f6f3ec] shadow-2xl flex flex-col relative z-10" style={{ height: "720px" }}>
        <div className="px-6 pt-12 pb-8 text-center hero-animated relative">
          {onSkip && (
            <button
              onClick={onSkip}
              aria-label="Continuer sans compte"
              className="absolute top-4 right-4 text-white/80"
            >
              <X size={18} />
            </button>
          )}
          <p className="text-white text-xl tracking-wide" style={serif}>My Store</p>
          <p className="text-white/80 text-sm italic mt-1.5" style={serif}>édition privée</p>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="flex bg-neutral-200/60 rounded-xl p-1 mb-6">
            <button
              onClick={() => {
                setMode("login");
                setError(null);
              }}
              className={`flex-1 text-xs font-medium py-2 rounded-lg ${
                mode === "login" ? "bg-white text-[#0c1f1d] shadow" : "text-neutral-400"
              }`}
            >
              Connexion
            </button>
            <button
              onClick={() => {
                setMode("signup");
                setError(null);
              }}
              className={`flex-1 text-xs font-medium py-2 rounded-lg ${
                mode === "signup" ? "bg-white text-[#0c1f1d] shadow" : "text-neutral-400"
              }`}
            >
              Inscription
            </button>
          </div>

          <div className="flex flex-col gap-3 mb-5">
            {mode === "signup" && (
              <>
                <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
                  <User size={16} className="text-neutral-400 flex-shrink-0" />
                  <input
                    value={form.name}
                    onChange={update("name")}
                    placeholder="Nom complet"
                    className="flex-1 text-sm outline-none bg-transparent"
                  />
                </div>

                <div>
                  <p className="text-xs text-neutral-400 mb-1.5 px-1">Tu es...</p>
                  <div className="flex bg-neutral-200/60 rounded-lg p-1">
                    <button
                      onClick={() => setRole("customer")}
                      className={`flex-1 text-xs font-medium py-1.5 rounded-md ${
                        role === "customer" ? "bg-white text-[#0c1f1d] shadow" : "text-neutral-400"
                      }`}
                    >
                      Client
                    </button>
                    <button
                      onClick={() => setRole("vendor")}
                      className={`flex-1 text-xs font-medium py-1.5 rounded-md ${
                        role === "vendor" ? "bg-white text-[#0c1f1d] shadow" : "text-neutral-400"
                      }`}
                    >
                      Vendeur
                    </button>
                  </div>
                </div>
              </>
            )}
            <div className="flex bg-neutral-200/60 rounded-lg p-1">
              <button
                onClick={() => setContactMethod("email")}
                className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-medium py-1.5 rounded-md ${
                  contactMethod === "email" ? "bg-white text-[#0c1f1d] shadow" : "text-neutral-400"
                }`}
              >
                <Mail size={13} />
                Email
              </button>
              <button
                onClick={() => setContactMethod("phone")}
                className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-medium py-1.5 rounded-md ${
                  contactMethod === "phone" ? "bg-white text-[#0c1f1d] shadow" : "text-neutral-400"
                }`}
              >
                <Phone size={13} />
                Téléphone
              </button>
            </div>

            {contactMethod === "email" && (
              <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
                <Mail size={16} className="text-neutral-400 flex-shrink-0" />
                <input
                  value={form.email}
                  onChange={update("email")}
                  placeholder="Adresse email"
                  className="flex-1 text-sm outline-none bg-transparent"
                />
              </div>
            )}
            {contactMethod === "phone" && (
              <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
                <Phone size={16} className="text-neutral-400 flex-shrink-0" />
                <input
                  value={form.phone}
                  onChange={update("phone")}
                  placeholder="Numéro de téléphone"
                  className="flex-1 text-sm outline-none bg-transparent"
                />
              </div>
            )}
            <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
              <Lock size={16} className="text-neutral-400 flex-shrink-0" />
              <input
                type={showPassword ? "text" : "password"}
                value={form.password}
                onChange={update("password")}
                placeholder="Mot de passe"
                className="flex-1 text-sm outline-none bg-transparent"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                className="text-neutral-400 flex-shrink-0"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && <p className="text-xs text-red-500 mb-3 text-center">{error}</p>}

          <button
            onClick={submit}
            disabled={submitting}
            className={`w-full text-sm font-medium py-3.5 rounded-2xl mb-3 ${
              submitting ? "bg-neutral-200 text-neutral-400" : "bg-[#0c1f1d] text-white"
            }`}
          >
            {submitting
              ? mode === "login"
                ? "Connexion..."
                : "Création du compte..."
              : mode === "login"
              ? "Se connecter"
              : "Créer mon compte"}
          </button>

          <p className="text-center text-xs text-neutral-400">
            {mode === "login" ? (
              <>
                Pas encore de compte ?{" "}
                <button onClick={() => setMode("signup")} className="text-[#00867e] underline">
                  Inscris-toi
                </button>
              </>
            ) : (
              <>
                Déjà un compte ?{" "}
                <button onClick={() => setMode("login")} className="text-[#00867e] underline">
                  Connecte-toi
                </button>
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="bg-white border border-neutral-200 rounded-2xl p-3.5">
      <p className="text-[10px] text-neutral-400 mb-1">{label}</p>
      <p className="text-lg text-[#0c1f1d]" style={serif}>{value}</p>
    </div>
  );
}

function DashboardScreen({ orders, allProducts, stockLevels, onBack }) {
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrders = orders.length;
  const totalItemsSold = orders.reduce(
    (sum, o) => sum + o.items.reduce((s, i) => s + i.qty, 0),
    0
  );

  const salesByProduct = {};
  orders.forEach((o) =>
    o.items.forEach((item) => {
      if (!salesByProduct[item.id]) {
        salesByProduct[item.id] = { name: item.name, qty: 0, revenue: 0 };
      }
      salesByProduct[item.id].qty += item.qty;
      salesByProduct[item.id].revenue += item.price * item.qty;
    })
  );
  const topProducts = Object.values(salesByProduct)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);
  const maxQty = topProducts[0]?.qty || 1;

  const lowStock = allProducts.filter((p) => (stockLevels[p.id] ?? 0) <= 3);

  return (
    <>
      <div className="px-6 pt-7 pb-8 flex items-center gap-3 hero-animated">
        <button
          onClick={onBack}
          aria-label="Retour"
          className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center text-white flex-shrink-0"
        >
          <ChevronLeft size={18} />
        </button>
        <h1 className="text-white text-lg" style={serif}>Tableau de bord</h1>
      </div>

      <div className="px-6 py-5">
        <div className="grid grid-cols-2 gap-3 mb-6">
          <StatCard label="Revenu total" value={format(totalRevenue)} />
          <StatCard label="Commandes" value={totalOrders} />
          <StatCard label="Articles vendus" value={totalItemsSold} />
          <StatCard label="Stock à surveiller" value={lowStock.length} />
        </div>

        <p className="text-xs font-medium text-[#0c1f1d] mb-3">Produits les plus vendus</p>
        {topProducts.length === 0 ? (
          <p className="text-xs text-neutral-400 mb-6">Aucune vente pour l'instant.</p>
        ) : (
          <div className="flex flex-col gap-3 mb-6">
            {topProducts.map((p) => (
              <div key={p.name}>
                <div className="flex justify-between text-xs text-[#0c1f1d] mb-1">
                  <span>{p.name}</span>
                  <span className="text-neutral-400">{p.qty} vendu{p.qty > 1 ? "s" : ""}</span>
                </div>
                <div className="h-2 bg-neutral-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${(p.qty / maxQty) * 100}%`, background: "#00c2b8" }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        <p className="text-xs font-medium text-[#0c1f1d] mb-3">Stock à surveiller</p>
        {lowStock.length === 0 ? (
          <p className="text-xs text-neutral-400">Tout est bien approvisionné ✅</p>
        ) : (
          <div className="flex flex-col gap-2">
            {lowStock.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between bg-white border border-neutral-200 rounded-xl px-3.5 py-2.5"
              >
                <span className="text-sm text-[#0c1f1d]">{p.name}</span>
                <span className="text-xs text-red-500 font-medium">
                  {stockLevels[p.id] ?? 0} restant{(stockLevels[p.id] ?? 0) > 1 ? "s" : ""}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

function ProfileScreen({ user, onOpenOrders = () => {}, onOpenDashboard = () => {}, onLogout = () => {}, onSave = () => {} }) {
  const [form, setForm] = useState(user);

  useEffect(() => {
    setForm(user);
  }, [user.name, user.email, user.phone, user.address]);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });
  const initials = (form.name || "?").split(" ").map((n) => n[0]).join("").slice(0, 2);
  const isVendor = user.role === "vendor";

  return (
    <>
      <div className="px-6 pt-7 pb-14 relative hero-animated">
        <h1 className="text-white text-lg" style={serif}>Mon compte</h1>
        <div className="absolute left-1/2 -translate-x-1/2 -bottom-9 flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center text-xl text-[#00c2b8] shadow-lg" style={serif}>
            {initials}
          </div>
          <span className="mt-1.5 text-[10px] font-medium px-2 py-0.5 rounded-full bg-white/90 text-[#0c1f1d]">
            {isVendor ? "Vendeur" : "Client"}
          </span>
        </div>
      </div>

      <div className="px-6 pt-16 pb-5">
        {isVendor && (
          <button
            onClick={onOpenDashboard}
            className="w-full flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3 mb-3 text-left"
          >
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white flex-shrink-0" style={{ background: "#00c2b8" }}>
              <BarChart3 size={18} />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#0c1f1d]">Tableau de bord</p>
              <p className="text-xs text-neutral-400 mt-0.5">Ventes, revenus et stock</p>
            </div>
            <ChevronLeft size={16} className="rotate-180 text-neutral-300" />
          </button>
        )}

        <button
          onClick={onOpenOrders}
          className="w-full flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3 mb-5 text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-[#0c1f1d] flex items-center justify-center text-white flex-shrink-0">
            <Package size={18} />
          </div>
          <div className="flex-1">
            <p className="text-sm text-[#0c1f1d]">Mes commandes</p>
            <p className="text-xs text-neutral-400 mt-0.5">Suivre ou consulter l'historique</p>
          </div>
          <ChevronLeft size={16} className="rotate-180 text-neutral-300" />
        </button>

        <p className="text-xs text-neutral-400 mb-3">Informations personnelles</p>
        <div className="flex flex-col gap-3 mb-6">
          <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
            <User size={16} className="text-neutral-400 flex-shrink-0" />
            <input value={form.name} onChange={update("name")} className="flex-1 text-sm text-[#0c1f1d] outline-none bg-transparent" placeholder="Nom complet" />
          </div>
          <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
            <Mail size={16} className="text-neutral-400 flex-shrink-0" />
            <input value={form.email} onChange={update("email")} className="flex-1 text-sm text-[#0c1f1d] outline-none bg-transparent" placeholder="Adresse email" />
          </div>
          <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
            <Phone size={16} className="text-neutral-400 flex-shrink-0" />
            <input value={form.phone} onChange={update("phone")} className="flex-1 text-sm text-[#0c1f1d] outline-none bg-transparent" placeholder="Numéro de téléphone" />
          </div>
          <div className="flex items-center gap-3 bg-white border border-neutral-200 rounded-2xl px-4 py-3">
            <MapPin size={16} className="text-neutral-400 flex-shrink-0" />
            <input value={form.address} onChange={update("address")} className="flex-1 text-sm text-[#0c1f1d] outline-none bg-transparent" placeholder="Adresse de livraison" />
          </div>
        </div>

        <button
          onClick={() => onSave(form)}
          className="w-full bg-[#0c1f1d] text-white text-sm font-medium py-3.5 rounded-2xl mb-3"
        >
          Enregistrer
        </button>
        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 text-sm text-neutral-500 py-2"
        >
          <LogOut size={15} />
          Se déconnecter
        </button>
      </div>
    </>
  );
}

/* ---------- App shell with bottom navigation ---------- */

export default function MaisonSenteurAppShell() {
  const [toast, setToast] = useState(null);
  const showToast = (message) => {
    setToast(message);
    window.clearTimeout(showToast._t);
    showToast._t = window.setTimeout(() => setToast(null), 1800);
  };

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    role: "customer",
  });

  // Real Firebase Authentication: watches sign-in state across the whole app,
  // and keeps the Firestore profile doc (users/{uid}) in sync in real time.
  useEffect(() => {
    let unsubProfile = () => {};
    const unsubAuth = onAuthStateChanged(auth, (firebaseUser) => {
      unsubProfile();
      if (firebaseUser) {
        setIsLoggedIn(true);
        const profileRef = doc(db, "users", firebaseUser.uid);
        unsubProfile = onSnapshot(profileRef, (snap) => {
          if (snap.exists()) {
            setCurrentUser({ uid: firebaseUser.uid, ...snap.data() });
          }
        });
      } else {
        setIsLoggedIn(false);
        setCurrentUser({ name: "", email: "", phone: "", address: "", role: "customer" });
      }
      setAuthLoading(false);
    });
    return () => {
      unsubAuth();
      unsubProfile();
    };
  }, []);

  const saveProfile = (updates) => {
    if (!currentUser.uid) return;
    updateDoc(doc(db, "users", currentUser.uid), updates);
  };

  const [tab, setTab] = useState("home");
  const [authRedirectTab, setAuthRedirectTab] = useState("home");

  const requireAuth = (targetTab) => {
    setAuthRedirectTab(targetTab);
    setTab("authGate");
  };

  const [categoryFilter, setCategoryFilter] = useState("Tout");
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [favorites, setFavorites] = usePersistentState("ms_favorites", []);

  const toggleFavorite = (productId) => {
    setFavorites((prev) => {
      const isFav = prev.includes(productId);
      showToast(isFav ? "Retiré des favoris" : "Ajouté aux favoris ♥");
      return isFav ? prev.filter((id) => id !== productId) : [...prev, productId];
    });
  };
  const [cart, setCart] = usePersistentState("ms_cart", []);

  // Orders live in their own Firestore collection so the vendor and every
  // customer see the same live order history and status across devices.
  const [orders, setOrdersState] = useState([]);
  useEffect(() => {
    const q = query(collection(db, "orders"), orderBy("date", "desc"));
    const unsubscribe = onSnapshot(q, (snap) => {
      setOrdersState(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return () => unsubscribe();
  }, []);

  const [orderConfirmed, setOrderConfirmed] = useState(false);
  const [confirmedTotal, setConfirmedTotal] = useState(0);
  // Shared catalog (products, stock, photos, descriptions, vendor logo) lives
  // in a single Firestore document (catalog/main) so every device — vendor
  // and customers alike — sees the same data in real time.
  const [catalog, setCatalogState] = useState({
    productImages: {},
    vendorLogo: null,
    productDescriptions: {},
    customProducts: [],
    productOverrides: {},
    deletedProductIds: [],
    stockLevels: {},
  });

  useEffect(() => {
    const catalogRef = doc(db, "catalog", "main");
    const unsubscribe = onSnapshot(catalogRef, (snap) => {
      if (snap.exists()) {
        setCatalogState((prev) => ({ ...prev, ...snap.data() }));
      } else {
        // First ever launch: seed the shared doc with the built-in products' stock.
        const initialStock = {};
        products.forEach((p) => {
          initialStock[p.id] = p.stock ?? 0;
        });
        setDoc(catalogRef, {
          productImages: {},
          vendorLogo: null,
          productDescriptions: {},
          customProducts: [],
          productOverrides: {},
          deletedProductIds: [],
          stockLevels: initialStock,
        });
      }
    });
    return () => unsubscribe();
  }, []);

  const {
    productImages,
    vendorLogo,
    productDescriptions,
    customProducts,
    productOverrides,
    deletedProductIds,
    stockLevels,
  } = catalog;

  const updateCatalog = (updates) => updateDoc(doc(db, "catalog", "main"), updates);
  const setVendorLogoUrl = (url) => updateCatalog({ vendorLogo: url });

  const uploadVendorLogo = async (file) => {
    const url = await uploadImageToStorage(file, `store/logo-${Date.now()}-${file.name}`);
    setVendorLogoUrl(url);
  };

  // Reviews live in their own collection (one doc per review) so the list can
  // grow without bumping into the 1MB-per-document Firestore limit.
  const [productReviews, setProductReviewsState] = useState({});

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "reviews"), (snap) => {
      const grouped = {};
      snap.docs.forEach((d) => {
        const data = d.data();
        if (!grouped[data.productId]) grouped[data.productId] = [];
        grouped[data.productId].push({ id: d.id, ...data });
      });
      setProductReviewsState(grouped);
    });
    return () => unsubscribe();
  }, []);

  const addReview = async (productId, review) => {
    await addDoc(collection(db, "reviews"), { productId, ...review });
    showToast("Avis publié, merci !");
  };

  const addProduct = (product) => {
    updateCatalog({
      customProducts: [...customProducts, product],
      stockLevels: { ...stockLevels, [product.id]: product.stock ?? 20 },
    });
    showToast("Produit ajouté");
  };

  const updateProduct = (productId, updates) => {
    updateCatalog({
      productOverrides: {
        ...productOverrides,
        [productId]: { ...(productOverrides[productId] || {}), ...updates },
      },
    });
    showToast("Produit modifié");
  };

  const deleteProduct = (productId) => {
    updateCatalog({ deletedProductIds: [...deletedProductIds, productId] });
    showToast("Produit supprimé");
  };

  const setProductDescription = (productId, text) => {
    updateCatalog({ productDescriptions: { ...productDescriptions, [productId]: text } });
  };

  // Uploads the photo to Firebase Storage, then appends its URL to the
  // product's photo gallery in the shared catalog doc.
  const addProductImage = async (product, file) => {
    const path = `products/${product.id}/${Date.now()}-${file.name}`;
    const url = await uploadImageToStorage(file, path);
    const existing = productImages[product.id] ?? (product.image ? [product.image] : []);
    updateCatalog({ productImages: { ...productImages, [product.id]: [...existing, url] } });
  };

  const removeProductImage = (product, index) => {
    const existing = productImages[product.id] ?? (product.image ? [product.image] : []);
    updateCatalog({
      productImages: { ...productImages, [product.id]: existing.filter((_, i) => i !== index) },
    });
  };

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const addToCart = (product, quantity = 1) => {
    setOrderConfirmed(false);
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      const existingQty = existing?.qty ?? 0;
      const available = stockLevels[product.id] ?? 0;
      const room = Math.max(0, available - existingQty);
      const qtyToAdd = Math.min(quantity, room);
      if (qtyToAdd <= 0) {
        showToast("Stock insuffisant");
        return prev;
      }
      showToast(`${product.name} ajouté au panier`);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, qty: item.qty + qtyToAdd } : item
        );
      }
      return [...prev, { ...product, qty: qtyToAdd }];
    });
  };

  const completePurchase = async (methodId) => {
    const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0) + (cart.length > 0 ? deliveryFee : 0);
    const updatedStock = { ...stockLevels };
    cart.forEach((item) => {
      updatedStock[item.id] = Math.max(0, (updatedStock[item.id] ?? 0) - item.qty);
    });
    await updateCatalog({ stockLevels: updatedStock });
    await addDoc(collection(db, "orders"), {
      date: new Date().toISOString(),
      items: cart.map((item) => ({ id: item.id, name: item.name, qty: item.qty, price: item.price })),
      total,
      method: methodId,
      status: ORDER_STATUS_FLOW[0],
      userId: currentUser.uid ?? null,
    });
    setConfirmedTotal(total);
    setOrderConfirmed(true);
    setCart([]);
  };

  const dismissConfirmation = () => {
    setOrderConfirmed(false);
    setTab("home");
  };

  const advanceOrderStatus = (orderId) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;
    const currentIndex = ORDER_STATUS_FLOW.indexOf(order.status);
    const nextStatus = ORDER_STATUS_FLOW[Math.min(currentIndex + 1, ORDER_STATUS_FLOW.length - 1)];
    updateDoc(doc(db, "orders", orderId), { status: nextStatus });
    showToast(`Commande marquée "${nextStatus}"`);
  };

  const updateCartQty = (productId, newQty) => {
    setCart((prev) => {
      if (newQty <= 0) {
        return prev.filter((item) => item.id !== productId);
      }
      const available = stockLevels[productId] ?? 0;
      const clamped = Math.min(newQty, available);
      return prev.map((item) => (item.id === productId ? { ...item, qty: clamped } : item));
    });
  };

  const goToCategory = (categoryName) => {
    setCategoryFilter(categoryName);
    setTab("home");
  };

  const openProductDetail = (product) => {
    setSelectedProductId(product.id);
    setTab("detail");
  };

  const openFavorites = () => setTab("favorites");

  const allProducts = [...products, ...customProducts]
    .filter((p) => !deletedProductIds.includes(p.id))
    .map((p) => ({ ...p, ...(productOverrides[p.id] || {}) }));
  const selectedProduct = allProducts.find((p) => p.id === selectedProductId) || null;
  const favoriteProducts = allProducts.filter((p) => favorites.includes(p.id));

  const tabs = [
    { id: "home", label: "Accueil", icon: Home },
    { id: "categories", label: "Catégories", icon: Grid3x3 },
    { id: "payment", label: "Panier", icon: ShoppingBag },
    { id: "profile", label: "Profil", icon: User },
  ];

  const screens = {
    home: (
      <HomeScreen
        onOpenCart={() => setTab("payment")}
        categoryFilter={categoryFilter}
        onSelectCategory={setCategoryFilter}
        onAddToCart={addToCart}
        cartCount={cartCount}
        productImages={productImages}
        onAddProductImage={addProductImage}
        vendorLogo={vendorLogo}
        onSetVendorLogo={uploadVendorLogo}
        productDescriptions={productDescriptions}
        onSetProductDescription={setProductDescription}
        allProducts={allProducts}
        onAddProduct={addProduct}
        stockLevels={stockLevels}
        onOpenDetail={openProductDetail}
        favorites={favorites}
        onToggleFavorite={toggleFavorite}
        onOpenFavorites={openFavorites}
        productReviews={productReviews}
        isVendor={currentUser.role === "vendor"}
      />
    ),
    categories: <CategoriesScreen onSelectCategory={goToCategory} allProducts={allProducts} />,
    payment: (
      <PaymentScreen
        cart={cart}
        onPay={completePurchase}
        onUpdateQty={updateCartQty}
        stockLevels={stockLevels}
        orderConfirmed={orderConfirmed}
        confirmedTotal={confirmedTotal}
        onDismissConfirmation={dismissConfirmation}
        isLoggedIn={isLoggedIn}
        onRequireAuth={() => requireAuth("payment")}
      />
    ),
    profile: (
      <ProfileScreen
        user={currentUser}
        onOpenOrders={() => setTab("orders")}
        onOpenDashboard={() => setTab("dashboard")}
        onLogout={() => signOut(auth)}
        onSave={saveProfile}
      />
    ),
    orders: (
      <OrdersScreen
        orders={orders}
        onBack={() => setTab("profile")}
        onAdvanceStatus={advanceOrderStatus}
        isVendor={currentUser.role === "vendor"}
      />
    ),
    dashboard: (
      <DashboardScreen
        orders={orders}
        allProducts={allProducts}
        stockLevels={stockLevels}
        onBack={() => setTab("profile")}
      />
    ),
    favorites: (
      <FavoritesScreen
        favoriteProducts={favoriteProducts}
        productImages={productImages}
        stockLevels={stockLevels}
        onToggleFavorite={toggleFavorite}
        onAddToCart={addToCart}
        onOpenDetail={openProductDetail}
        onBack={() => setTab("home")}
      />
    ),
    detail: (
      <ProductDetailScreen
        product={selectedProduct}
        stockLevels={stockLevels}
        productImages={productImages}
        onAddProductImage={addProductImage}
        onRemoveProductImage={removeProductImage}
        productDescriptions={productDescriptions}
        onSetProductDescription={setProductDescription}
        onAddToCart={addToCart}
        onUpdateProduct={updateProduct}
        onDeleteProduct={deleteProduct}
        reviews={productReviews[selectedProduct?.id] ?? []}
        onAddReview={addReview}
        reviewerName={currentUser.name}
        isVendor={currentUser.role === "vendor"}
        onBack={() => setTab("home")}
      />
    ),
  };

  if (tab === "authGate") {
    return <AuthScreen onAuthSuccess={() => setTab(authRedirectTab)} onSkip={() => setTab("home")} />;
  }

  return (
    <div className="w-full flex justify-center bg-neutral-100 p-6 relative overflow-hidden">
      <AnimatedBackgroundStyles />
      <AmbientBackdrop />
      <div className="w-[360px] rounded-[36px] overflow-hidden bg-[#f6f3ec] shadow-2xl flex flex-col relative z-10" style={{ height: "720px" }}>
        {toast && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-[#0c1f1d] text-white text-xs font-medium px-4 py-2.5 rounded-full shadow-lg whitespace-nowrap">
            {toast}
          </div>
        )}
        <div className="flex-1 overflow-y-auto">
          {screens[tab]}
        </div>

        {tab !== "detail" && tab !== "favorites" && tab !== "orders" && tab !== "dashboard" && (
          <div
            className="flex justify-around items-center py-3 flex-shrink-0"
            style={{ background: "#00c2b8" }}
          >
            {tabs.map(({ id, label, icon: Icon }) => {
              const isActive = tab === id;
              return (
                <button
                  key={id}
                  onClick={() => (id === "profile" && !isLoggedIn ? requireAuth("profile") : setTab(id))}
                  className="relative flex flex-col items-center gap-1 px-2"
                  aria-label={label}
                >
                  <Icon size={20} className={isActive ? "text-white" : "text-white/50"} />
                  {id === "payment" && cartCount > 0 && (
                    <span className="absolute -top-1 right-1 bg-[#003c39] text-white text-[8px] font-semibold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
                  <span className={`text-[10px] ${isActive ? "text-white" : "text-white/50"}`}>
                    {label}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
