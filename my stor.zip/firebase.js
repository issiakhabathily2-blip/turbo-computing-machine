// firebase.js
//
// Initializes Firebase for the app. This file needs YOUR project's config,
// which you get for free by creating a Firebase project.
//
// SETUP (see FIREBASE_SETUP.md for the full walkthrough):
// 1. Go to https://console.firebase.google.com, create a project (free).
// 2. In the project, enable: Authentication (Email/Password), Firestore
//    Database, and Storage.
// 3. In Project Settings > General > "Your apps", add a Web app.
//    Firebase will show you a config object like the one below —
//    copy YOUR values into firebaseConfig.
// 4. Install the SDK in your project: npm install firebase

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
