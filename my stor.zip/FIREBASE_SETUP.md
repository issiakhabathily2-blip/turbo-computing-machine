# Mettre en place Firebase pour My Store

Ce guide t'accompagne pour passer de la sauvegarde locale (`localStorage`, un
seul appareil) à un vrai backend partagé (Firebase, tous les appareils voient
la même chose). C'est gratuit pour démarrer.

## 1. Créer le projet

1. Va sur https://console.firebase.google.com
2. Clique "Ajouter un projet", donne-lui un nom (ex: `my-store`)
3. Tu peux désactiver Google Analytics si tu ne veux pas t'en servir

## 2. Activer les 3 services dont l'app a besoin

Dans le menu de gauche de la console Firebase :

**Authentication**
- Clique "Authentication" → "Get started"
- Onglet "Sign-in method" → active **Email/Password**

**Firestore Database** (stocke produits, commandes, avis...)
- Clique "Firestore Database" → "Create database"
- Choisis "Start in test mode" pour l'instant (on sécurisera les règles plus tard)
- Choisis une région proche de toi (ex: `eur3` pour l'Europe)

**Storage** (stocke les vraies photos)
- Clique "Storage" → "Get started"
- Là aussi, "test mode" pour commencer

## 3. Récupérer ta config

1. Clique sur l'icône ⚙️ (Paramètres du projet) en haut à gauche
2. Descends jusqu'à "Vos applications"
3. Clique sur l'icône `</>` (Web) pour ajouter une app web
4. Donne-lui un nom (ex: "My Store Web"), pas besoin de cocher "Hosting"
5. Firebase affiche un objet `firebaseConfig` — copie ces valeurs dans le
   fichier `firebase.js` fourni (remplace les `"YOUR_..."`)

## 4. Installer le SDK dans ton projet

Dans le dossier de ton projet React :

```bash
npm install firebase
```

## 5. Règles de sécurité (important avant de publier l'app)

Le "mode test" laisse tout le monde lire/écrire pendant 30 jours, puis ça se
bloque automatiquement. Avant de publier réellement l'app, remplace les
règles Firestore par quelque chose comme :

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Tout le monde peut lire le catalogue et les avis
    match /catalog/{doc} {
      allow read: if true;
      allow write: if request.auth != null; // connecté = peut écrire
    }
    match /reviews/{reviewId} {
      allow read: if true;
      allow create: if request.auth != null;
    }
    // Commandes : lecture/écriture réservée aux connectés
    match /orders/{orderId} {
      allow read, write: if request.auth != null;
    }
    // Chaque utilisateur ne modifie que son propre profil
    match /users/{userId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Pour une vraie protection "seul le vendeur peut modifier les produits", il
faudrait vérifier le rôle stocké dans `users/{uid}` — dis-le-moi quand tu en
es là, on l'ajoutera.

## 6. C'est prêt

Une fois ces 3 services activés et `firebase.js` rempli avec ta config,
le reste du code (dans `MaisonSenteurAppShell.jsx`) est déjà branché dessus.
